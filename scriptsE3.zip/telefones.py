numero = 920000000
numeros = []
for i in range(100):
    numeros.append(numero + i)
print(numeros)
print(len(numeros))